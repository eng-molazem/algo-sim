const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 6 },
    role: { type: String, enum: ['student', 'instructor'], default: 'student' },
    preferredLanguage: { type: String, enum: ['ar', 'en'], default: 'ar' },
    instructorModeEnabled: { type: Boolean, default: false },
    completedAlgorithms: { type: [String], default: [] },
  },
  { timestamps: true }
);

userSchema.pre('save', async function hashPassword(next) {
  if (!this.isModified('password')) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

userSchema.methods.comparePassword = function comparePassword(candidate) {
  return bcrypt.compare(candidate, this.password);
};

userSchema.methods.toSafeObject = function toSafeObject() {
  return {
    id: this._id,
    name: this.name,
    email: this.email,
    role: this.role,
    preferredLanguage: this.preferredLanguage,
    instructorModeEnabled: this.instructorModeEnabled,
    completedAlgorithms: this.completedAlgorithms,
    createdAt: this.createdAt,
  };
};

module.exports = mongoose.model('User', userSchema);
